物流筐收发管理系统 - APK 打包图标
====================================
使用说明（HBuilderX / Capacitor / Android Studio 打包时使用）：

1. 主图标（应用图标/安装显示）：
   - ic_launcher_512.png    (512x512)
   - ic_launcher_1024.png   (1024x1024, 商店用)

2. 安卓自适应图标（Adaptive Icon，Android 8+）：
   - ic_launcher_foreground.png  (1024x1024, 透明底前景，"筐"字在安全区)
   - ic_launcher_background.png  (1024x1024, 纯蓝底)
   - 配合 ic_launcher.xml（adaptive-icon 配置）

3. 各密度 legacy 图标（mipmap）：
   - mipmap-mdpi/ic_launcher.png       48x48
   - mipmap-hdpi/ic_launcher.png       72x72
   - mipmap-xhdpi/ic_launcher.png      96x96
   - mipmap-xxhdpi/ic_launcher.png     144x144
   - mipmap-xxxhdpi/ic_launcher.png    192x192
   - ic_launcher_round.png 为圆形版本

HBuilderX 云打包：发"制作应用图标"时上传 ic_launcher_1024.png 或 512。
Capacitor/Android：把 mipmap-* 目录复制到 android/app/src/main/res/，
ic_launcher_background/foreground.png 放 mipmap-xxxhdpi，XML 放 mipmap-anydpi-v26。
